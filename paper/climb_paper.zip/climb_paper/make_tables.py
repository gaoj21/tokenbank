import re, glob
"""Generate every results table of the paper from the result files (run from the repo root)."""
import json
M = json.load(open('results/main_table_final.json'))
A = json.load(open('results/ablations_glm.json'))
X = json.load(open('results/appendix_glm.json'))
MG = json.load(open('results/monotone_gain.json'))
CELLS = [('GLM', b) for b in ('MATH', 'GAIA', 'FRAMES', 'MuSiQue')] + [('DeepSeek', b) for b in ('MATH', 'GAIA', 'FRAMES', 'MuSiQue')]
mn = lambda f: 'GLM' if f == 'GLM' else 'DeepSeek'
def at(acc, tok, bold_tok=False, bold_acc=False):
    a = f'\\textbf{{{acc:.1f}}}' if bold_acc else f'{acc:.1f}'
    t = f'\\textbf{{{tok:.0f}\\%}}' if bold_tok else f'{tok:.0f}\\%'
    return f'{a} / {t}'
out = {}

# ---------------- main table (pipeline vs CLIMB) and baselines (appendix) ----------------
rows, brows = [], []
for i, (f, b) in enumerate(CELLS):
    r = M[f'{f}|{b}']; pa = r['pipe_acc']
    cells = [f"{pa:.1f} / {r['pipe_tok']/1000:.1f}k"]
    for e in ('eps2', 'eps5', 'eps10'):
        cells.append(at(r[e]['acc'], r[e]['tok'], bold_tok=r[e]['tok'] < 50, bold_acc=r[e]['acc'] >= pa))
    viol = max(r[e]['viol_pool'] for e in r if e.startswith('eps'))
    lead = (f'\\multirow{{4}}{{*}}{{{mn(f)}}}' if i % 4 == 0 else '')
    sep = '\n\\midrule' if i == 3 else ''
    rows.append(f"{lead} & {b} & " + ' & '.join(cells) + f" & {viol:.1f}\\% \\\\" + sep)
    bcells = [f"{pa:.1f} / 100\\%"] + [at(r[k][0], r[k][1]) for k in ('L0', 'L1', 'fixed', 'oracle')] + [at(r['eps5']['acc'], r['eps5']['tok'])]
    brows.append(f"{lead} & {b} & " + ' & '.join(bcells) + " \\\\" + sep)
out['tab_main'] = r"""\begin{table*}[t]
\centering
\small
\begin{tabular}{@{}llcccccc@{}}
\toprule
& & & \multicolumn{3}{c}{\climb{}} & \\
\cmidrule(lr){4-6}
Model & Benchmark & Pipeline & $\eps = 2\%$ & $\eps = 5\%$ & $\eps = 10\%$ & Viol. \\
\midrule
""" + '\n'.join(rows) + r"""
\bottomrule
\end{tabular}
\caption{Replay results: accuracy / tokens as a share of the pipeline's (pipeline: accuracy / mean tokens), averaged over
200 calibration/evaluation splits. Viol.\ is the largest share of splits, over the three tolerances, in which the chosen
policy's empirical loss on the full recorded pool exceeds $\eps$. This diagnostic is not itself the population-risk
event controlled at $\delta = 10\%$. Bold: under 50\% of the
pipeline's tokens, or at least as accurate as the pipeline. Uncertified baselines are in Table~\ref{tab:baselines}.}
\label{tab:main}
\end{table*}
"""
out['tab_baselines'] = r"""\begin{table*}[h]
\centering
\small
\begin{tabular}{@{}llcccccc@{}}
\toprule
Model & Benchmark & Pipeline & Always $L_0$ & Always $L_1$ & Fixed $t = -0.10$ & Oracle & \climb{} ($\eps = 5\%$) \\
\midrule
""" + '\n'.join(brows) + r"""
\bottomrule
\end{tabular}
\caption{Uncertified baselines on the full test split, accuracy / tokens as a share of the pipeline's. Always $L_k$ stops
every task at rung $k$; Oracle stops at the cheapest rung that answers correctly. None of these carries a guarantee;
\climb{} is repeated from Table~\ref{tab:main}.}
\label{tab:baselines}
\end{table*}
"""

# ---------------- calibration design (GLM) ----------------
names = [('betting', 'Betting, signed loss (ours)'), ('combined', 'Betting $\\cup$ binomial'),
         ('binom', 'Binomial, harm'), ('bonf', 'Binomial, Bonferroni'),
         ('hoef_h', 'Hoeffding, harm'), ('hoef_l', 'Hoeffding, signed loss')]
C = A['calibration_design']; rows = []
for k, nm in names:
    rows.append(nm + ' & ' + ' & '.join(f"{C[b][k][0]}\\%" for b in ('MATH', 'GAIA', 'FRAMES', 'MuSiQue')) + ' \\\\')
out['tab_calib'] = r"""\begin{table}[t]
\centering
\footnotesize
\setlength{\tabcolsep}{2.5pt}
\resizebox{\columnwidth}{!}{%
\begin{tabular}{@{}lrrrr@{}}
\toprule
Test (GLM, $\eps{=}5\%$) & MATH & GAIA & FRAMES & MuSiQue \\
\midrule
""" + '\n'.join(rows) + r"""
\bottomrule
\end{tabular}}
\caption{Tokens (\% of pipeline) under different certification tests, same fixed-sequence procedure and splits; every test
keeps the empirical finite-pool violation rate below the nominal level $\delta$.}
\label{tab:calib}
\end{table}
"""

# ---------------- appendix: monotone ----------------
rows = [f"{r['fam'].replace('DeepSeek','DS')} & {r['ds']} & $L_{r['rung'][1]}$ & " + ' & '.join(f'${100*v:+.1f}$' for v in r['gain']) + f" & ${r['rho']:+.2f}$ \\\\" for r in MG]
out['tab_monotone'] = r"""\begin{table}[h]
\centering
\scriptsize
\setlength{\tabcolsep}{2.5pt}
\resizebox{\columnwidth}{!}{%
\begin{tabular}{@{}lllrrrrrr@{}}
\toprule
Model & Bench. & Rung & Q1 & Q2 & Q3 & Q4 & Q5 & $\rho$ \\
\midrule
""" + '\n'.join(rows) + r"""
\bottomrule
\end{tabular}}
\caption{Accuracy gain from escalating to the pipeline (points) by confidence quintile (Q1 least confident), and Spearman
$\rho$ between quintile and gain. $\rho \le 0$ in """ + str(sum(r['rho'] <= 0 for r in MG)) + r""" of 16 rows.}
\label{tab:monotone}
\end{table}
"""

# ---------------- appendix: delta / n / shift ----------------
B = ('MATH', 'GAIA', 'FRAMES', 'MuSiQue')
rows = [f"$\\delta = {d}$ & " + ' & '.join(f"{X['delta'][b][d][0]}\\% / {X['delta'][b][d][1]:.0f}\\%" for b in B) + ' \\\\' for d in ('0.05', '0.1', '0.2')]
rows.append('\\midrule')
for n in ('50', '100', '200'):
    rows.append(f"$n = {n}$ & " + ' & '.join((f"{X['n'][b][n][0]}\\% / {X['n'][b][n][1]:.0f}\\%" if n in X['n'][b] else '--') for b in B) + ' \\\\')
out['tab_sens'] = r"""\begin{table}[h]
\centering
\scriptsize
\setlength{\tabcolsep}{3pt}
\begin{tabular}{@{}lcccc@{}}
\toprule
GLM, $\eps = 5\%$ & MATH & GAIA & FRAMES & MuSiQue \\
\midrule
""" + '\n'.join(rows) + r"""
\bottomrule
\end{tabular}
\caption{Sensitivity: tokens (\% of pipeline) / violation rate, as the error level $\delta$ and the calibration size $n$ vary
(default $\delta = 0.1$, $n$ = half of the test split).}
\label{tab:sens}
\end{table}
"""
rows = []
for src in B:
    rows.append(f"{src} & " + ' & '.join(('--' if src == dst else f"{X['shift'][src][dst]['tok']}\\% / ${X['shift'][src][dst]['risk']:+.1f}$") for dst in B) + ' \\\\')
out['tab_shift'] = r"""\begin{table}[h]
\centering
\scriptsize
\setlength{\tabcolsep}{3pt}
\resizebox{\columnwidth}{!}{%
\begin{tabular}{@{}lcccc@{}}
\toprule
Calibrated on $\downarrow$ / deployed on $\rightarrow$ & MATH & GAIA & FRAMES & MuSiQue \\
\midrule
""" + '\n'.join(rows) + r"""
\bottomrule
\end{tabular}}
\caption{Distribution shift (GLM, $\eps = 5\%$): tokens / risk (points) when the threshold calibrated on one benchmark is
deployed on another. Risk above 5 violates the tolerance.}
\label{tab:shift}
\end{table}
"""
for k, v in out.items():
    open(f'paper/sections/{k}.tex', 'w').write(v)
print('wrote', list(out))

# ---------------- appendix: single call (4k cap) and generation caps ----------------
import statistics as _st
def _single(path):
    L = [json.loads(l) for l in open(path)]
    return 100 * _st.mean(x['success'] for x in L), _st.mean(x['total_used'] for x in L)
SINGLE = {'GLM|MATH': 'traces/tasks_sweep_GLM-5.3-Flash_glms4k_ma24.jsonl', 'GLM|GAIA': 'traces/tasks_sweep_GLM-5.3-Flash_glms4k_ga24.jsonl',
          'GLM|FRAMES': 'traces/tasks_sweep_GLM-5.3-Flash_glms4k_fr24.jsonl', 'GLM|MuSiQue': 'traces/tasks_sweep_GLM-5.3-Flash_glmfp8s_mu24.jsonl',
          'DeepSeek|MATH': 'traces/tasks_sweep_DeepSeek-V4.1-Flash_dss4k_ma24.jsonl', 'DeepSeek|GAIA': 'traces/tasks_sweep_DeepSeek-V4.1-Flash_dss4k_ga24.jsonl',
          'DeepSeek|FRAMES': 'traces/tasks_sweep_DeepSeek-V4.1-Flash_dss4k_fr24.jsonl', 'DeepSeek|MuSiQue': 'traces/tasks_sweep_DeepSeek-V4.1-Flash_dss4k_mu24.jsonl'}
rows = []
for k, pth in SINGLE.items():
    a, t = _single(pth); r = M[k]
    rows.append(f"{k.replace('DeepSeek','DS').replace('|',' ')} & {a:.1f} / {t/1000:.1f}k & {r['eps5']['acc']:.1f} & {r['pipe_acc']:.1f} / {r['pipe_tok']/1000:.1f}k \\\\")
open('paper/sections/tab_single.tex', 'w').write(r"""\begin{table}[h]
\centering
\small
\setlength{\tabcolsep}{3pt}
\begin{tabular}{@{}lrrr@{}}
\toprule
& Single call & \climb{} ($\eps{=}5\%$) & Pipeline \\
\midrule
""" + '\n'.join(rows) + r"""
\bottomrule
\end{tabular}
\caption{One executor call with default reasoning and the same 4{,}096 cap, for reference.}
\label{tab:single}
\end{table}
""")
CAPS = json.load(open('results/caps_table.json'))
fmt = lambda v: f"${v[0]:+.1f}" + ("^{*}$" if v[1] else "$")
rows = [f"{r['cell']} & {fmt(r['24'])} & {fmt(r['16'])} & {fmt(r['8'])} \\\\" for r in CAPS]
open('paper/sections/tab_caps.tex', 'w').write(r"""\begin{table}[h]
\centering
\small
\begin{tabular}{@{}lrrr@{}}
\toprule
& 24k & 16k & 8k \\
\midrule
""" + '\n'.join(rows) + r"""
\bottomrule
\end{tabular}
\caption{Accuracy change of the plain pipeline from a 1{,}024 to a 4{,}096 per-call cap, by task
budget. $^{*}$: $p < 0.05$, exact McNemar.}
\label{tab:caps}
\end{table}
""")
print('wrote tab_single, tab_caps')

# ---------------- appendix: expanded tables ----------------
RUNG = json.load(open('results/rung_table.json'))
rows = []
for i, (f, b) in enumerate(CELLS):
    r = RUNG[f'{f}|{b}']; lead = (f'\\multirow{{4}}{{*}}{{{mn(f)}}}' if i % 4 == 0 else '')
    cells = [f"{r[k][0]:.1f} / {r[k][1]/1000:.1f}k" for k in ('L0', 'L1', 'S', 'P')]
    rows.append(f"{lead} & {b} & " + ' & '.join(cells) + f" & {r['auc0']:.2f} & {r['auc1']:.2f} & {r['rescue']:.1f} & {r['harm']:.1f} \\\\" + ('\n\\midrule' if i == 3 else ''))
open('paper/sections/tab_rungs.tex', 'w').write(r"""\begin{table*}[h]
\centering
\small
\setlength{\tabcolsep}{4pt}
\resizebox{\textwidth}{!}{%
\begin{tabular}{@{}llccccccrr@{}}
\toprule
Model & Bench. & $L_0$ & $L_1$ (cum.) & $L_2$ seeded (cum.) & Pipeline & AUROC $L_0$ & AUROC $L_1$ & Rescue & Harm \\
\midrule
""" + '\n'.join(rows) + r"""
\bottomrule
\end{tabular}}
\caption{Per-rung accuracy / mean cumulative tokens on the full test split, from the deployed-configuration records.
AUROC of each rung's confidence for its own correctness. Rescue: share of tasks the pipeline answers correctly and $L_0$
does not; Harm: the reverse (\%).}
\label{tab:rungs}
\end{table*}
""")
ROLE = {}
for line in open('results/role_shares.txt'):
    m = re.match(r'\s+(GLM|DeepSeek)\s+(\S+)\s+planner\s+([\d.]+)%\s+executor\s+([\d.]+)%\s+reviewer\s+([\d.]+)%', line)
    if m: ROLE[(m.group(1), m.group(2))] = tuple(float(x) for x in m.group(3, 4, 5))
rows = [f"{mn(f)} & {b} & {ROLE[(f, b)][0]:.1f} & {ROLE[(f, b)][1]:.1f} & {ROLE[(f, b)][2]:.1f} & {ROLE[(f, b)][0] + ROLE[(f, b)][2]:.1f} \\\\"
        for f in ('GLM', 'DeepSeek') for b in ('MATH', 'GAIA', 'FRAMES', 'MuSiQue', 'pooled')]
open('paper/sections/tab_roles.tex', 'w').write(r"""\begin{table}[h]
\centering
\small
\setlength{\tabcolsep}{3pt}
\resizebox{\columnwidth}{!}{%
\begin{tabular}{@{}llrrrr@{}}
\toprule
Model & Bench. & Planner & Executor & Reviewer & Coord. \\
\midrule
""" + '\n'.join(rows) + r"""
\bottomrule
\end{tabular}}
\caption{Share (\%) of the plain pipeline's tokens by role (24k budget, 4{,}096 cap). Coord.: planner + reviewer.}
\label{tab:roles}
\end{table}
""")
SWP = {}
for pth in glob.glob('results/eps_sweep_*.json'):
    d = json.load(open(pth)); SWP[(d['fam'], d['ds'])] = d
EPSL = ['0.01', '0.02', '0.03', '0.05', '0.075', '0.1']
rows = []
for i, (f, b) in enumerate(CELLS):
    d = SWP[(f, b)]; lead = (f'\\multirow{{4}}{{*}}{{{mn(f)}}}' if i % 4 == 0 else '')
    rows.append(f"{lead} & {b} & " + ' & '.join(f"{d['sweep'][e]['tok']:.0f} / {d['pipe_acc'] - d['sweep'][e]['acc']:.1f}" for e in EPSL) + " \\\\" + ('\n\\midrule' if i == 3 else ''))
open('paper/sections/tab_sweep.tex', 'w').write(r"""\begin{table*}[h]
\centering
\small
\begin{tabular}{@{}llcccccc@{}}
\toprule
Model & Bench. & $\eps = 1\%$ & $2\%$ & $3\%$ & $5\%$ & $7.5\%$ & $10\%$ \\
\midrule
""" + '\n'.join(rows) + r"""
\bottomrule
\end{tabular}
\caption{Tolerance sweep: tokens (\% of pipeline) / accuracy loss (points) of \climb{}, 100 calibration/evaluation splits per
point. Violation rates are at most """ + f"{max(v['viol'] for d in SWP.values() for v in d['sweep'].values()):.0f}" + r"""\% at every point.}
\label{tab:sweep}
\end{table*}
""")
POL = A['policies']; PV = A.get('policy_violations_eval', {})
rows = [f"{b} & " + ' & '.join(f"{POL[b][m]:.1f}" for m in 'ABCDE') + " \\\\" for b in ('MATH', 'GAIA', 'FRAMES', 'MuSiQue')]
open('paper/sections/tab_policies.tex', 'w').write(r"""\begin{table}[h]
\centering
\small
\begin{tabular}{@{}lrrrrr@{}}
\toprule
GLM & A & B & C & D & E \\
\midrule
""" + '\n'.join(rows) + r"""
\bottomrule
\end{tabular}
\caption{Tokens (\% of pipeline) at $\eps = 5\%$ for the five escalation policies of \S\ref{sec:variants} (200 splits,
40/20/40). A: shared threshold (\climb{}); B: separate thresholds; C: answer agreement; D: Bayes deciles; E: learned values.}
\label{tab:policies}
\end{table}
""")
rows = []
for k, nm in names:
    rows.append(nm + ' & ' + ' & '.join(f"{C[b][k][0]} / {C[b][k][1]:.1f}" for b in ('MATH', 'GAIA', 'FRAMES', 'MuSiQue')) + ' \\\\')
open('paper/sections/tab_calib_full.tex', 'w').write(r"""\begin{table}[h]
\centering
\footnotesize
\setlength{\tabcolsep}{2.5pt}
\resizebox{\columnwidth}{!}{%
\begin{tabular}{@{}lcccc@{}}
\toprule
Test (GLM, $\eps{=}5\%$) & MATH & GAIA & FRAMES & MuSiQue \\
\midrule
""" + '\n'.join(rows) + r"""
\bottomrule
\end{tabular}}
\caption{Tokens (\% of pipeline) / violation rate (\%) for each certification test (200 splits).}
\label{tab:calib_full}
\end{table}
""")
print('wrote tab_rungs, tab_roles, tab_sweep, tab_policies, tab_calib_full')

# ---------------- appendix: i.i.d. guarantee check and (A1) test ----------------
G = json.load(open('paper/data/guarantee_iid.json'))
rows = []
for i, (f, b) in enumerate(CELLS):
    r = G[f'{f}|{b}']; lead = (f'\\multirow{{4}}{{*}}{{{mn(f)}}}' if i % 4 == 0 else '')
    cells = [f"{100*o['viol']:.1f} {{\\scriptsize[{100*o['ci'][0]:.1f}, {100*o['ci'][1]:.1f}]}} & {100*o['tok']:.0f}"
             for o in (r['out'][e] for e in ('0.02', '0.05', '0.1'))]
    rows.append(f"{lead} & {b} & {r['n']} & " + ' & '.join(cells) + " \\\\" + ('\n\\midrule' if i == 3 else ''))
open('paper/sections/tab_iid.tex', 'w').write(r"""\begin{table*}[h]
\centering
\small
\setlength{\tabcolsep}{4pt}
\resizebox{\textwidth}{!}{%
\begin{tabular}{@{}llrcrcrcr@{}}
\toprule
& & & \multicolumn{2}{c}{$\eps = 2\%$} & \multicolumn{2}{c}{$\eps = 5\%$} & \multicolumn{2}{c}{$\eps = 10\%$} \\
\cmidrule(lr){4-5}\cmidrule(lr){6-7}\cmidrule(lr){8-9}
Model & Bench. & $n$ & $\Pr(R > \eps)$ [95\% CI] & Tok. & $\Pr(R > \eps)$ [95\% CI] & Tok. & $\Pr(R > \eps)$ [95\% CI] & Tok. \\
\midrule
""" + '\n'.join(rows) + r"""
\bottomrule
\end{tabular}}
\caption{Direct check of Proposition~\ref{prop:risk}. The task distribution is the recorded pool; $n$ calibration tasks
(half the pool) are drawn i.i.d.\ from it, \climb{} is calibrated ($\delta = 10\%$), and the deployed policy's risk under
that distribution is computed exactly. $\Pr(R > \eps)$: share of 5{,}000 draws in which it exceeds $\eps$ (\%), with a
Clopper--Pearson interval; Tok.: mean tokens (\% of pipeline).}
\label{tab:iid}
\end{table*}
""")
A1 = json.load(open('paper/data/a1_sufficiency.json'))
def a1cell(o, auc=True):
    s = f"${1000*o['gain']:+.1f}$ {{\\scriptsize[{1000*o['ci'][0]:+.1f}, {1000*o['ci'][1]:+.1f}]}}"
    if auc: s += f" & ${o['dauc']:+.3f}$ {{\\scriptsize[{o['dauc_ci'][0]:+.2f}, {o['dauc_ci'][1]:+.2f}]}}"
    return s.replace('+-', '-')
rows = []
for i, (f, b) in enumerate(CELLS):
    r = A1[f'{f}|{b}|S']; lead = (f'\\multirow{{4}}{{*}}{{{mn(f)}}}' if i % 4 == 0 else '')
    rows.append(f"{lead} & {b} & " + ' & '.join(a1cell(r['out'][t]) for t in ('Y1', 'Y2', 'YK')) + ' & ' + a1cell(r['out']['logdC'], False)
                + " \\\\" + ('\n\\midrule' if i == 3 else ''))
open('paper/sections/tab_a1.tex', 'w').write(r"""\begin{table*}[h]
\centering
\small
\setlength{\tabcolsep}{3pt}
\resizebox{\textwidth}{!}{%
\begin{tabular}{@{}llccccccc@{}}
\toprule
& & \multicolumn{2}{c}{$Y_1$ (stop at $L_1$)} & \multicolumn{2}{c}{$Y_2$ (seeded team)} & \multicolumn{2}{c}{$Y_K$ (reference)} & $\log(C_2 - C_1)$ \\
\cmidrule(lr){3-4}\cmidrule(lr){5-6}\cmidrule(lr){7-8}\cmidrule(lr){9-9}
Model & Bench. & $\Delta$log-loss & $\Delta$AUC & $\Delta$log-loss & $\Delta$AUC & $\Delta$log-loss & $\Delta$AUC & $\Delta$MSE \\
\midrule
""" + '\n'.join(rows) + r"""
\bottomrule
\end{tabular}}
\caption{Test of (A1) at $L_1$: held-out improvement from adding the earlier score $S_0$ to a model that sees $S_1$
(cross-fitted, $5 \times 10$ folds; log-loss and MSE reductions $\times 10^{-3}$, positive = history helps; 95\% bootstrap
intervals over tasks).}
\label{tab:a1}
\end{table*}
""")
print('wrote tab_iid, tab_a1')
