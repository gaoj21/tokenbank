# Per-task records and assumption checks

`records.csv`: one row per (model, benchmark, test task), 6,232 rows; every replay number in the paper is computed from these.

| column | meaning |
|---|---|
| S0, S1 | confidence of L0 / L1: mean token log-probability of the rung's final call |
| H0, H1 | mean top-5 entropy of that call (a rung may stop only if it is at most 0.6) |
| Y0, Y1, Y2 | correctness of L0, L1 and the seeded L2 (team given the draft), from the deployed-CLIMB records |
| C0, C1, C2 | cumulative ledger tokens up to and including that rung |
| YK, CK | correctness and tokens of the reference pipeline (no draft); the loss is YK minus the policy's correctness |

Scripts in `../analysis/` (Python 3, numpy, pandas, scipy, scikit-learn), run from the project root:

- `python analysis/guarantee_iid.py` writes `guarantee_iid.json` (Appendix D, Table 4; about 2 minutes on 8 cores).
- `python analysis/a1_sufficiency.py` writes `a1_sufficiency.json` (Appendix D, Table 5; about 4 minutes on 16 cores).

`climb_core.py` implements the policy, betting test and calibration, and matches the repository implementation on 120 random calibrations.
