"""Ablation figures (native PowerPoint shapes): fig_variants.pptx and fig_state.pptx."""
import json
from figstyle import *

# ---------------- richer escalation policies: tokens under the same guarantee ----------------
V = json.load(open('fig_variants.json'))['rows']
LAB = {'GLM|MATH': 'MATH', 'GLM|GAIA': 'GAIA', 'GLM|FRAMES': 'FRAMES', 'GLM|MuSiQue': 'MuSiQue'}
POL = [('B', 'two thresholds', '7E57C2', MSO_SHAPE.DIAMOND), ('C', 'agreement', '00897B', MSO_SHAPE.ISOSCELES_TRIANGLE),
       ('D', 'Bayes deciles', 'F9A825', MSO_SHAPE.RECTANGLE), ('E', 'learned values', '8D6E63', MSO_SHAPE.OVAL)]
F = Slide(3.3, 1.78); s = F
X0, PW, Y0, RH = 0.70, 2.48, 0.46, 0.235
xmin, xmax = 0, 100
xx = lambda v: X0 + (v - xmin) / (xmax - xmin) * PW
for gx in (0, 20, 40, 60, 80, 100):
    s.line(xx(gx), Y0 - 0.04, xx(gx), Y0 + 4 * RH, color='E6E6E6', lw=0.6, head=False)
    s.text((xx(gx) - 0.2, Y0 + 4 * RH + 0.02, 0.4, 0.12), [[soft(f'{gx}%', size=6.2)]])
s.text((X0, Y0 + 4 * RH + 0.15, PW, 0.12), [[soft('GLM · tokens (% of pipeline) at ε = 5%  ·  lower is better', size=6.4)]])
for i, r in enumerate(V):
    y = Y0 + (i + 0.5) * RH
    s.text((0.0, y - 0.065, X0 - 0.08, 0.13), [[(LAB[r['cell']], {'size': 6.8})]], align=PP_ALIGN.RIGHT)
    vals = [r[p] for p in 'ABCDE']
    s.line(xx(min(vals)), y, xx(max(vals)), y, color='BDBDBD', lw=1.2, head=False)
    for p, name, col, shp in POL:
        d = 0.075
        s.box(xx(r[p]) - d / 2, y - d / 2, d, d, 'FFFFFF', col, shape=shp, lw=1.0)
    d = 0.10
    s.box(xx(r['A']) - d / 2, y - d / 2, d, d, C['ink'], C['ink'], shape=MSO_SHAPE.OVAL, lw=0.8)
# legend: CLIMB on the first row, the four alternatives on the second
s.box(0.05, 0.05, 0.08, 0.08, C['ink'], C['ink'], shape=MSO_SHAPE.OVAL)
s.text((0.16, 0.025, 2.5, 0.13), [[('A  shared threshold (CLIMB)', {'size': 6.4, 'bold': True})]], align=PP_ALIGN.LEFT)
for j, (p, name, col, shp) in enumerate(POL):
    x = 0.05 + j * 0.80
    s.box(x, 0.215, 0.07, 0.07, 'FFFFFF', col, shape=shp, lw=1.0)
    s.text((x + 0.10, 0.185, 0.70, 0.13), [[(f'{p}  {name}', {'size': 6.2, 'color': C['soft']})]], align=PP_ALIGN.LEFT)
F.save('fig_variants.pptx')

# ---------------- state ablation: accuracy change ----------------
S = json.load(open('fig_state.json'))
COL = ['3B6EA8', 'E8A36B']          # GLM MATH, GLM GAIA
F = Slide(3.3, 2.05); s = F
X0, PW, Y0, RH = 1.42, 1.80, 0.36, 0.27
xmin, xmax = -15, 5
xx = lambda v: X0 + (v - xmin) / (xmax - xmin) * PW
s.box(X0, Y0 + 3 * RH, PW, 2 * RH, 'FBEDED', None, shape=MSO_SHAPE.RECTANGLE)
for gx in (-15, -10, -5, 0, 5):
    s.line(xx(gx), Y0, xx(gx), Y0 + 5 * RH, color='9A9A9A' if gx == 0 else 'E6E6E6', lw=0.9 if gx == 0 else 0.6, head=False)
    s.text((xx(gx) - 0.2, Y0 + 5 * RH + 0.02, 0.4, 0.12), [[soft(f'{gx:+d}'.replace('+0', '0').replace('-', '−'), size=6.2)]])
s.text((X0, Y0 + 5 * RH + 0.15, PW, 0.12), [[soft('accuracy change vs. pipeline (points)', size=6.4)]])
s.line(0.05, Y0 + 3 * RH, X0 + PW, Y0 + 3 * RH, color='CFCFCF', lw=0.6, head=False, dash=True)
s.text((0.05, Y0 + 0.02, 1.2, 0.12), [[('compress the state', {'size': 6.2, 'italic': True, 'color': C['soft']})]], align=PP_ALIGN.LEFT)
s.text((0.05, Y0 + 3 * RH + 0.02, 1.3, 0.12), [[('compress the reviewer', {'size': 6.2, 'italic': True, 'color': C['bad']})]], align=PP_ALIGN.LEFT)
for i, (name, vals, sig) in enumerate(S['rows']):
    y = Y0 + (i + 0.5) * RH + 0.04
    s.text((0.05, y - 0.06, X0 - 0.1, 0.13), [[(name, {'size': 6.4})]], align=PP_ALIGN.RIGHT)
    for j, (v, g) in enumerate(zip(vals, sig)):
        d = 0.085; dy = (j - 0.5) * 0.045
        s.box(xx(v) - d / 2, y + dy - d / 2, d, d, COL[j] if g else 'FFFFFF', COL[j], shape=MSO_SHAPE.OVAL, lw=1.0)
# legend
for j, lab in enumerate(S['settings']):
    x = 0.05 + j * 0.80
    s.box(x, 0.06, 0.08, 0.08, COL[j], COL[j], shape=MSO_SHAPE.OVAL)
    s.text((x + 0.11, 0.035, 0.7, 0.13), [[(lab, {'size': 6.3})]], align=PP_ALIGN.LEFT)
s.text((0.05, 0.19, 3.2, 0.12), [[soft('filled: p < 0.05 (exact McNemar)', size=6.0)]], align=PP_ALIGN.LEFT)
F.save('fig_state.pptx')
print('saved')
