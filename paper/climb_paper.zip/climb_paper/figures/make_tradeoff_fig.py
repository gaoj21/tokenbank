"""Figure: (a) tokens vs tolerance eps for all eight settings; (b) tokens vs calibration size n (GLM).
Native PowerPoint XY charts. Data: results/eps_sweep_*.json, results/appendix_glm.json."""
import json, glob
from figstyle import *
from pptx.chart.data import XyChartData
from pptx.enum.chart import XL_CHART_TYPE, XL_LEGEND_POSITION, XL_MARKER_STYLE
from pptx.enum.dml import MSO_LINE_DASH_STYLE
BEN = ['MATH', 'GAIA', 'FRAMES', 'MuSiQue']
COL = {'MATH': '3B6EA8', 'GAIA': 'B55A1E', 'FRAMES': '2E7D32', 'MuSiQue': '7E57C2'}
SW = {}
for f in glob.glob('../../results/eps_sweep_*.json'):
    d = json.load(open(f)); SW[(d['fam'], d['ds'])] = d['sweep']
AP = json.load(open('../../results/appendix_glm.json'))

def style_xy(ch, xmin, xmax, xmajor, xfmt, ymin=0, ymax=100, ymajor=25):
    ch.font.name = 'Arial'; ch.font.size = Pt(6.5); ch.has_title = False; ch.has_legend = False
    va, ca = ch.value_axis, ch.category_axis
    for ax in (va, ca):
        ax.tick_labels.font.size = Pt(6.5); ax.format.line.color.rgb = RGBColor(0x88, 0x88, 0x88)
    va.minimum_scale, va.maximum_scale, va.major_unit = ymin, ymax, ymajor
    va.tick_labels.number_format = '0"%"'; va.tick_labels.number_format_is_linked = False
    va.has_major_gridlines = True; va.major_gridlines.format.line.color.rgb = RGBColor(0xE6, 0xE6, 0xE6)
    ca.minimum_scale, ca.maximum_scale, ca.major_unit = xmin, xmax, xmajor
    ca.tick_labels.number_format = xfmt; ca.tick_labels.number_format_is_linked = False
    ca.has_major_gridlines = False

def style_series(ser, color, dashed=False):
    ser.format.line.color.rgb = rgb(color); ser.format.line.width = Pt(1.3)
    if dashed: ser.format.line.dash_style = MSO_LINE_DASH_STYLE.DASH
    ser.marker.style = XL_MARKER_STYLE.CIRCLE; ser.marker.size = 4
    ser.marker.format.fill.solid(); ser.marker.format.fill.fore_color.rgb = rgb(color)
    ser.marker.format.line.color.rgb = rgb(color); ser.smooth = False

F = Slide(3.3, 3.0); s = F
# (a) tokens vs eps
s.text((0.02, 0.0, 3.2, 0.16), [[('(a) ', B), ('Tolerance', B), ('  ·  tokens (% of pipeline) vs. ε', {'size': 6.8, 'color': C['soft']})]], size=7.8, align=PP_ALIGN.LEFT)
cd = XyChartData(); order = []
for fam in ('GLM', 'DeepSeek'):
    for b in BEN:
        ser = cd.add_series(f'{fam} {b}'); order.append((fam, b))
        for e, v in sorted(SW[(fam, b)].items(), key=lambda kv: float(kv[0])):
            ser.add_data_point(100 * float(e), v['tok'])
ch = s.s.shapes.add_chart(XL_CHART_TYPE.XY_SCATTER_LINES, Inches(0.0), Inches(0.16), Inches(3.3), Inches(1.42), cd).chart
style_xy(ch, 0, 10, 2, '0"%"')
for ser, (fam, b) in zip(ch.plots[0].series, order): style_series(ser, COL[b], dashed=(fam == 'DeepSeek'))
# legend (manual): benchmark colours, line style per model
lx = 0.35
for j, b in enumerate(BEN):
    x = lx + j * 0.62
    s.line(x, 1.66, x + 0.16, 1.66, color=COL[b], lw=1.4, head=False)
    s.text((x + 0.19, 1.60, 0.45, 0.12), [[(b, {'size': 6.2})]], align=PP_ALIGN.LEFT)
s.line(lx, 1.80, lx + 0.16, 1.80, color='555555', lw=1.3, head=False); s.text((lx + 0.19, 1.74, 0.4, 0.12), [[('GLM', {'size': 6.2})]], align=PP_ALIGN.LEFT)
s.line(lx + 0.62, 1.80, lx + 0.78, 1.80, color='555555', lw=1.3, head=False, dash=True); s.text((lx + 0.81, 1.74, 0.6, 0.12), [[('DeepSeek', {'size': 6.2})]], align=PP_ALIGN.LEFT)
# (b) tokens vs n (GLM)
s.text((0.02, 1.92, 3.2, 0.16), [[('(b) ', B), ('Calibration size', B), ('  ·  GLM, ε = 5%, tokens vs. n', {'size': 6.8, 'color': C['soft']})]], size=7.8, align=PP_ALIGN.LEFT)
# drawn with native shapes (LibreOffice mis-renders XY series of unequal length)
X0, PW, TOPP, PH = 0.42, 2.78, 2.14, 0.66
xx = lambda n: X0 + n / 1000 * PW
yy = lambda v: TOPP + (100 - v) / 100 * PH
for v in (0, 50, 100):
    s.line(X0, yy(v), X0 + PW, yy(v), color='E6E6E6', lw=0.6, head=False)
    s.text((X0 - 0.36, yy(v) - 0.06, 0.32, 0.12), [[soft(f'{v}%', size=6.3)]], align=PP_ALIGN.RIGHT)
for n in (0, 200, 400, 600, 800, 1000):
    s.text((xx(n) - 0.2, TOPP + PH + 0.02, 0.4, 0.12), [[soft(str(n), size=6.3)]])
s.line(X0, TOPP + PH, X0 + PW, TOPP + PH, color='888888', lw=0.7, head=False)
for b in BEN:
    pts = sorted((int(n), v[0]) for n, v in AP['n'][b].items())
    for (n1, v1), (n2, v2) in zip(pts, pts[1:]):
        s.line(xx(n1), yy(v1), xx(n2), yy(v2), color=COL[b], lw=1.3, head=False)
    for n, v in pts:
        s.box(xx(n) - 0.025, yy(v) - 0.025, 0.05, 0.05, COL[b], COL[b], shape=MSO_SHAPE.OVAL, lw=0.5)
F.save('fig_tradeoff.pptx'); print('saved')
