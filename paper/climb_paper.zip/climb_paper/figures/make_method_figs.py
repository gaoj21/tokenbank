"""Method figures as editable PowerPoint slides (single-column width).
figure_ladder.pptx: the escalation ladder (Figure 2); figure_calib.pptx: risk-controlled calibration (Figure 3)."""
from figstyle import *

# ======================= Figure 2: what escalation is based on =======================
import json
from pptx.util import Emu
DEC = json.load(open('figure2_deciles.json'))      # rescue / harm / net per confidence decile, pooled
def pav_decreasing(v):
    blocks = [[x, 1] for x in v]
    i = 0
    while i < len(blocks) - 1:
        if blocks[i][0] < blocks[i + 1][0]:
            m = (blocks[i][0] * blocks[i][1] + blocks[i + 1][0] * blocks[i + 1][1]) / (blocks[i][1] + blocks[i + 1][1])
            blocks[i] = [m, blocks[i][1] + blocks[i + 1][1]]; del blocks[i + 1]; i = max(i - 1, 0)
        else: i += 1
    out = []
    for m, w in blocks: out += [m] * w
    return out
NET = [d['net'] for d in DEC]; FIT = pav_decreasing(NET)
F = Slide(3.3, 2.56); s = F
X0, PW, TOPP, PH = 0.40, 2.80, 0.45, 1.55
ymax = max(d['rescue'] for d in DEC) + 0.02; ymin = -max(d['harm'] for d in DEC) - 0.02
yy = lambda v: TOPP + (ymax - v) / (ymax - ymin) * PH
Y0 = yy(0); BOT = TOPP + PH; K = len(DEC); step = PW / K
xc = lambda i: X0 + (i + 0.5) * step
price = 0.06                                  # illustrative price per token, lambda * delta-c
# threshold where the fitted gain first falls below the price
cut = next(i for i, v in enumerate(FIT) if v <= price)
tx = X0 + cut * step
s.box(X0, TOPP, tx - X0, PH, 'FDF1E6', None, shape=MSO_SHAPE.RECTANGLE)
s.box(tx, TOPP, X0 + PW - tx, PH, 'EAF4EA', None, shape=MSO_SHAPE.RECTANGLE)
s.text((tx - 1.25, TOPP - 0.15, 1.10, 0.13), [[('← escalate', {'size': 6.8, 'bold': True, 'color': C['pipe_l']})]], align=PP_ALIGN.RIGHT)
s.text((tx + 0.15, TOPP - 0.15, 1.10, 0.13), [[('stop →', {'size': 6.8, 'bold': True, 'color': C['ok']})]], align=PP_ALIGN.LEFT)
# rescue (up) and harm (down) bars
bw = step * 0.56
for i, d in enumerate(DEC):
    x = xc(i) - bw / 2
    s.box(x, yy(d['rescue']), bw, Y0 - yy(d['rescue']), 'F2C9A5', None, shape=MSO_SHAPE.RECTANGLE)
    s.box(x, Y0, bw, yy(-d['harm']) - Y0, 'D9D9D9', None, shape=MSO_SHAPE.RECTANGLE)
# zero line, price line
s.line(X0, Y0, X0 + PW, Y0, color='8A8A8A', lw=0.7, head=False)
s.line(X0, yy(price), X0 + PW, yy(price), color='444444', lw=0.8, head=False, dash=True)
s.text((X0 + PW - 0.5, yy(price) - 0.135, 0.5, 0.12), [[('λ·Δc', {'size': 6.6, 'italic': True})]], align=PP_ALIGN.RIGHT)
# net gain: CI whiskers and points
for i, d in enumerate(DEC):
    s.line(xc(i), yy(d['hi']), xc(i), yy(d['lo']), color='6B6B6B', lw=0.6, head=False)
    dot = s.box(xc(i) - 0.028, yy(d['net']) - 0.028, 0.056, 0.056, 'FFFFFF', '333333', shape=MSO_SHAPE.OVAL, lw=0.8)
# monotone (isotonic) fit as a polyline
pts = []
for i, v in enumerate(FIT):
    pts += [(X0 + i * step, yy(v)), (X0 + (i + 1) * step, yy(v))]
fb = s.s.shapes.build_freeform(Inches(pts[0][0]), Inches(pts[0][1]), scale=1.0)
fb.add_line_segments([(Inches(x), Inches(y)) for x, y in pts[1:]], close=False)
fit = fb.convert_to_shape(); fit.fill.background(); fit.line.color.rgb = rgb('1F1F1F'); fit.line.width = Pt(1.6)
Slide._plain(fit._element)
# threshold
s.line(tx, TOPP, tx, BOT + 0.02, color=C['ink'], lw=1.1, head=False)
s.text((tx - 0.2, TOPP - 0.15, 0.4, 0.13), [[('t*', {'size': 7.4, 'bold': True})]])
# axes and labels
s.line(X0, BOT, X0, TOPP - 0.04, color='8A8A8A', lw=0.7)
for v in (0.15, 0.1, 0.05, 0, -0.05):
    s.text((X0 - 0.30, yy(v) - 0.06, 0.26, 0.12), [[soft(f'{100 * v:+.0f}%'.replace('+0%', '0').replace('-', '−'), size=6.0)]], align=PP_ALIGN.RIGHT)
s.text((X0, BOT + 0.03, 0.6, 0.12), [[soft('low', size=6.2)]], align=PP_ALIGN.LEFT)
s.text((X0 + PW - 0.6, BOT + 0.03, 0.6, 0.12), [[soft('high', size=6.2)]], align=PP_ALIGN.RIGHT)
s.text((X0, BOT + 0.03, PW, 0.12), [[soft('confidence S of the cheap answer (decile)', size=6.4)]])
# legend row
ly = 0.06
s.box(X0, ly + 0.03, 0.13, 0.08, 'F2C9A5', None, shape=MSO_SHAPE.RECTANGLE)
s.text((X0 + 0.17, ly, 0.8, 0.13), [[soft('rescued by team', size=6.3)]], align=PP_ALIGN.LEFT)
s.box(X0 + 0.92, ly + 0.03, 0.13, 0.08, 'D9D9D9', None, shape=MSO_SHAPE.RECTANGLE)
s.text((X0 + 1.09, ly, 0.8, 0.13), [[soft('harmed by team', size=6.3)]], align=PP_ALIGN.LEFT)
s.line(X0 + 1.86, ly + 0.07, X0 + 2.02, ly + 0.07, color='1F1F1F', lw=1.6, head=False)
s.text((X0 + 2.06, ly, 0.9, 0.13), [[soft('net gain (fit)', size=6.3)]], align=PP_ALIGN.LEFT)
# decision rule
rule = s.box(X0, BOT + 0.20, PW, 0.28, 'FFFFFF', '9A9A9A', lw=0.7, radius=0.25)
s.text(rule, [[('escalate  ⇔  ', {'size': 7.2, 'bold': True}),
               ('E[rescue − harm | S] > λ·Δc', {'size': 7.2}), ('  ⇔  ', {'size': 7.2, 'bold': True}), ('S < t*', {'size': 7.2, 'bold': True})]])
F.save('figure_criterion.pptx')

# ======================= Figure 2a: what we escalate from and to =======================
F = Slide(3.3, 2.56); s = F
BASEY = 1.86
cards = [  # x, w, h, fill, line, rung, name, lines
    (0.04, 0.80, 0.98, C['cheap_f'], C['cheap_l'], 'L₀', 'Direct answer', ['executor', 'cheap reasoning', 'cap 2k / call', '0.3k–0.9k tok']),
    (1.12, 0.80, 1.14, C['cheap_f'], C['cheap_l'], 'L₁', 'Self-verify', ['executor + draft', 'cheap reasoning', 'cap 2k / call', '+0.3k–1.1k tok']),
    (2.20, 1.06, 1.62, C['pipe_f'], C['pipe_l'], 'L₂', 'Multi-agent team', None),
]
for x, w, h, f, l, rung, name, lines in cards:
    top = BASEY - h
    s.box(x, top, w, h, f, l, lw=0.9, radius=0.08)
    s.text((x, top + 0.05, w, 0.17), [[(rung, {'bold': True, 'size': 9})]])
    s.text((x, top + 0.23, w, 0.14), [[(name, {'bold': True, 'size': 7.0})]])
    if lines:
        s.text((x + 0.03, top + 0.42, w - 0.06, h - 0.46), [[soft(t, size=6.3)] for t in lines], anchor=MSO_ANCHOR.TOP)
# team internals: planner -> executor <-> reviewer, stacked
x, w, h = 2.20, 1.06, 1.62; top = BASEY - h
rw, rh = 0.66, 0.17; rx = x + (w - rw) / 2
ys = [top + 0.44, top + 0.70, top + 0.96]
for yv, lab in zip(ys, ['Planner', 'Executor', 'Reviewer']):
    r = s.box(rx, yv, rw, rh, 'FFFFFF', C['pipe_l'], lw=0.6, radius=0.4)
    r.text_frame.margin_left = r.text_frame.margin_right = Inches(0)
    s.text(r, [[(lab, {'size': 6.1})]])
s.line(rx + rw / 2, ys[0] + rh, rx + rw / 2, ys[1], color=C['pipe_l'], lw=0.6)
s.line(rx + rw / 2 - 0.08, ys[1] + rh, rx + rw / 2 - 0.08, ys[2], color=C['pipe_l'], lw=0.6)
s.line(rx + rw / 2 + 0.08, ys[2], rx + rw / 2 + 0.08, ys[1] + rh, color=C['pipe_l'], lw=0.6)
s.text((rx + rw + 0.01, ys[1] + 0.12, 0.2, 0.2), [[soft('≤5×', size=5.8)]], align=PP_ALIGN.LEFT)
s.text((x + 0.03, top + 1.18, w - 0.06, 0.42), [[soft('default reasoning', size=6.3)], [soft('cap 4k / call', size=6.3)], [soft('3.5k–15.5k tok', size=6.3)]], anchor=MSO_ANCHOR.TOP)
# escalate arrows (with draft) between cards
for (x1, w1, *_), (x2, *_) , k in ((cards[0], cards[1], '₀'), (cards[1], cards[2], '₁')):
    ya = BASEY - 0.62
    s.line(x1 + w1 + 0.02, ya, x2 - 0.02, ya, color=C['pipe_l'], lw=1.1)
    s.text((x1 + w1 - 0.04, ya - 0.27, x2 - x1 - w1 + 0.08, 0.13), [[(f'S{k} ≤ t*', {'size': 6.4, 'bold': True, 'color': C['pipe_l']})]])
    s.text((x1 + w1 - 0.04, ya - 0.15, x2 - x1 - w1 + 0.08, 0.12), [[('+ draft', {'size': 5.9, 'color': C['pipe_l']})]])
# answer bar and stop arrows
AY = 2.24
ab = s.box(0.04, AY, 3.22, 0.24, C['ans_f'], C['ans_l'], radius=0.3)
s.text(ab, [[('Final answer', {'bold': True, 'size': 7})]])
for (x, w, *_), k in zip(cards[:2], ('₀', '₁')):
    cx = x + w / 2
    s.line(cx, BASEY, cx, AY, color=C['ok'], lw=1.0)
    s.text((cx + 0.04, BASEY + 0.07, 0.6, 0.13), [[(f'S{k} > t*', {'size': 6.4, 'bold': True, 'color': C['ok']})]], align=PP_ALIGN.LEFT)
s.line(2.20 + 0.53, BASEY, 2.20 + 0.53, AY, color='555555', lw=1.0)
# cost cue
s.line(0.04, 0.12, 3.26, 0.12, color='9A9A9A', lw=0.8)
s.text((0.04, 0.0, 3.22, 0.1), [[soft('cost and coordination increase', italic=True, size=6.2)]], align=PP_ALIGN.LEFT)
F.save('figure_ladder.pptx')

# ======================= Figure 3: calibration =======================
F = Slide(3.3, 2.05); s = F
X0, BW, BG, BASE, TOPY = 0.40, 0.23, 0.075, 1.24, 0.42
cands = ['∅', 't₁', 't₂', 't₃', 't₄', 't₅', '…', 'tM']
harms = [0.0, 0.12, 0.25, 0.40, 0.70, 0.80, None, 0.92]     # schematic heights (fraction of plot)
state = ['ok', 'ok', 'ok', 'ok', 'bad', 'na', 'na', 'na']
PH = BASE - TOPY
crit = BASE - 0.55 * PH
# axes
s.line(X0 - 0.06, BASE, X0 + 8 * (BW + BG), BASE, color='8A8A8A', lw=0.8, head=False)
s.line(X0 - 0.06, BASE, X0 - 0.06, TOPY - 0.05, color='8A8A8A', lw=0.8)
tb = s.text((-0.33, 0.76, 0.86, 0.14), [[soft('evidence of loss > ε', size=6.3)]], size=6.3); tb.rotation = -90
# critical value line
s.line(X0 - 0.06, crit, X0 + 8 * (BW + BG) - BG + 0.02, crit, color=C['bad'], lw=0.8, head=False, dash=True)
s.text((X0 + 0.02, crit - 0.14, 1.15, 0.12), [[('certification boundary', {'size': 6.0, 'color': C['bad']})]], align=PP_ALIGN.LEFT)
for i, (lab, h, st) in enumerate(zip(cands, harms, state)):
    x = X0 + i * (BW + BG)
    col, fill = {'ok': (C['ok'], C['ok_f']), 'bad': (C['bad'], C['bad_f']), 'na': (C['na'], C['na_f'])}[st]
    if h is not None and h > 0:
        s.box(x, BASE - h * PH, BW, h * PH, fill, col, shape=MSO_SHAPE.RECTANGLE, lw=0.8, dash=(st == 'na'))
    lb = lab if lab != 'tM' else 't'
    runs = [(lb, {'bold': st != 'na', 'color': C['ink'] if st != 'na' else C['na'], 'size': 7.2})]
    if lab == 'tM': runs.append(('M', {'size': 5.5, 'color': C['na']}))
    s.text((x - 0.03, BASE + 0.03, BW + 0.06, 0.15), [runs])
    mark = {'ok': '✓', 'bad': '✗', 'na': ''}[st]
    if mark: s.text((x - 0.03, BASE + 0.17, BW + 0.06, 0.15), [[(mark, {'bold': True, 'color': col, 'size': 7.5})]])
# arrow: testing order
s.line(X0, 0.20, X0 + 8 * (BW + BG) - BG, 0.20, color=C['soft'], lw=0.8)
s.text((X0, 0.03, 2.4, 0.13), [[soft('test in order, conservative → aggressive', size=6.3)]], align=PP_ALIGN.LEFT)
s.text((X0 + 5 * (BW + BG) - 0.06, BASE + 0.175, 0.95, 0.14), [[('← first failure: stop', {'size': 6.3, 'color': C['bad'], 'bold': True})]], align=PP_ALIGN.LEFT)
# certified set bracket and selection
bx1, bx2, by = X0, X0 + 4 * (BW + BG) - BG, BASE + 0.38
s.line(bx1, by, bx2, by, color=C['ok'], lw=1.0, head=False)
s.line(bx1, by - 0.05, bx1, by, color=C['ok'], lw=1.0, head=False); s.line(bx2, by - 0.05, bx2, by, color=C['ok'], lw=1.0, head=False)
s.text((bx1, by + 0.02, bx2 - bx1, 0.14), [[('certified set 𝒞', {'size': 6.8, 'color': C['ok'], 'bold': True})]])
# deploy + guarantee
g = s.box(1.62, BASE + 0.34, 1.62, 0.44, C['ok_f'], C['ok'], lw=0.9)
s.text(g, [[('deploy t* = cheapest in 𝒞', {'bold': True, 'size': 6.9})],
           [('P[ risk > ε ] ≤ δ', {'size': 6.9})]])
F.save('figure_calib.pptx')
print('saved')
