"""Shared drawing style for the paper figures (native PowerPoint shapes)."""
from pptx import Presentation
from pptx.util import Inches, Pt
from pptx.dml.color import RGBColor
from pptx.enum.shapes import MSO_SHAPE, MSO_CONNECTOR
from pptx.enum.text import PP_ALIGN, MSO_ANCHOR
from pptx.oxml.ns import qn
from lxml import etree

FONT = 'Arial'
C = dict(ink='222222', soft='5F5F5F', cheap_f='E3EDF8', cheap_l='3B6EA8', pipe_f='FBE7D3', pipe_l='B55A1E',
         gate_f='FFFFFF', gate_l='7A7A7A', ans_f='F2F2F2', ans_l='9A9A9A', ok='2E7D32', ok_f='E3F1E4',
         bad='C62828', bad_f='FBE3E3', na='B8B8B8', na_f='F4F4F4')
rgb = RGBColor.from_string

class Slide:
    def __init__(self, w, h):
        self.prs = Presentation(); self.prs.slide_width, self.prs.slide_height = Inches(w), Inches(h)
        self.s = self.prs.slides.add_slide(self.prs.slide_layouts[6])
    @staticmethod
    def _plain(el):
        sp = el.spPr
        if sp.find(qn('a:effectLst')) is None: etree.SubElement(sp, qn('a:effectLst'))
        st = el.find(qn('p:style'))
        if st is not None:
            er = st.find(qn('a:effectRef'))
            if er is not None: er.set('idx', '0')
    def box(self, x, y, w, h, fill, line, shape=MSO_SHAPE.ROUNDED_RECTANGLE, lw=0.9, radius=0.18, dash=False):
        sh = self.s.shapes.add_shape(shape, Inches(x), Inches(y), Inches(w), Inches(h))
        if fill is None: sh.fill.background()
        else: sh.fill.solid(); sh.fill.fore_color.rgb = rgb(fill)
        if line is None: sh.line.fill.background()
        else: sh.line.color.rgb = rgb(line); sh.line.width = Pt(lw)
        if dash:
            d = etree.SubElement(sh.line._get_or_add_ln(), qn('a:prstDash')); d.set('val', 'dash')
        self._plain(sh._element)
        if shape == MSO_SHAPE.ROUNDED_RECTANGLE: sh.adjustments[0] = radius
        tf = sh.text_frame
        for m in ('margin_left', 'margin_right', 'margin_top', 'margin_bottom'): setattr(tf, m, Inches(0.02))
        return sh
    def text(self, target, paras, size=7.5, align=PP_ALIGN.CENTER, anchor=MSO_ANCHOR.MIDDLE):
        if isinstance(target, tuple):
            x, y, w, h = target
            target = self.s.shapes.add_textbox(Inches(x), Inches(y), Inches(w), Inches(h))
            for m in ('margin_left', 'margin_right', 'margin_top', 'margin_bottom'): setattr(target.text_frame, m, Inches(0))
        tf = target.text_frame; tf.word_wrap = True; tf.vertical_anchor = anchor
        for i, para in enumerate(paras):
            p = tf.paragraphs[0] if i == 0 else tf.add_paragraph(); p.alignment = align
            if isinstance(para, str): para = [(para, {})]
            for t, st in para:
                r = p.add_run(); r.text = t; f = r.font; f.name = FONT; f.size = Pt(st.get('size', size))
                f.bold = st.get('bold', False); f.italic = st.get('italic', False); f.color.rgb = rgb(st.get('color', C['ink']))
        return target
    def line(self, x1, y1, x2, y2, color='555555', lw=0.9, head=True, dash=False):
        c = self.s.shapes.add_connector(MSO_CONNECTOR.STRAIGHT, Inches(x1), Inches(y1), Inches(x2), Inches(y2))
        c.line.color.rgb = rgb(color); c.line.width = Pt(lw); ln = c.line._get_or_add_ln()
        if dash:
            d = etree.SubElement(ln, qn('a:prstDash')); d.set('val', 'dash')
        if head:
            t = etree.SubElement(ln, qn('a:tailEnd')); t.set('type', 'triangle'); t.set('w', 'sm'); t.set('len', 'sm')
        self._plain(c._element)
        return c
    def save(self, path): self.prs.save(path)

B = {'bold': True}
def soft(t, **k): return (t, {'color': C['soft'], 'size': k.get('size', 6.8), 'italic': k.get('italic', False)})

