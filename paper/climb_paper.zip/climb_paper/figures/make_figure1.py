"""Figure 1 (motivation) as an editable PowerPoint slide with native charts.
Data are read from figure1_data.json (built from results/*.json); role shares from analysis/role_decomp.py."""
import json
from pptx import Presentation
from pptx.util import Inches, Pt
from pptx.dml.color import RGBColor
from pptx.chart.data import CategoryChartData
from pptx.enum.chart import XL_CHART_TYPE, XL_LEGEND_POSITION, XL_LABEL_POSITION, XL_TICK_LABEL_POSITION
from pptx.enum.text import PP_ALIGN, MSO_ANCHOR

D = json.load(open('figure1_data.json'))
BENCH = ['MATH', 'GAIA', 'FRAMES', 'MuSiQue']
ROLES = {'GLM': (21.1, 47.6, 31.3), 'DeepSeek': (30.3, 42.2, 27.5)}   # planner, executor, reviewer (%)
W, H = 8.0, 2.35
prs = Presentation(); prs.slide_width, prs.slide_height = Inches(W), Inches(H)
s = prs.slides.add_slide(prs.slide_layouts[6])
FONT = 'Arial'; INK = RGBColor(0x22, 0x22, 0x22); SOFT = RGBColor(0x55, 0x55, 0x55)
GLM_C, DS_C = RGBColor(0x3B, 0x6E, 0xA8), RGBColor(0x9C, 0xBC, 0xE0)
PLAN_C, EXE_C, REV_C = RGBColor(0xE0, 0x8A, 0x3C), RGBColor(0xC9, 0xD6, 0xE6), RGBColor(0xB5, 0x5A, 0x1E)
FIX_C, CLIMB_C = RGBColor(0xC6, 0x28, 0x28), RGBColor(0x2E, 0x7D, 0x32)

def label(x, y, w, h, runs, size=8, align=PP_ALIGN.LEFT, anchor=MSO_ANCHOR.TOP):
    tb = s.shapes.add_textbox(Inches(x), Inches(y), Inches(w), Inches(h)); tf = tb.text_frame
    tf.word_wrap = True; tf.vertical_anchor = anchor
    for m in ('margin_left', 'margin_right', 'margin_top', 'margin_bottom'): setattr(tf, m, Inches(0))
    for i, para in enumerate(runs):
        p = tf.paragraphs[0] if i == 0 else tf.add_paragraph(); p.alignment = align
        for t, st in para:
            r = p.add_run(); r.text = t; f = r.font; f.name = FONT; f.size = Pt(st.get('size', size))
            f.bold = st.get('bold', False); f.italic = st.get('italic', False); f.color.rgb = st.get('color', INK)

def style(chart, ymin=None, ymax=None, major=None, fmt=None, legend=True, size=7):
    chart.font.name = FONT; chart.font.size = Pt(size); chart.font.color.rgb = INK
    chart.has_title = False
    chart.has_legend = legend
    if legend:
        chart.legend.position = XL_LEGEND_POSITION.TOP; chart.legend.include_in_layout = False
        chart.legend.font.size = Pt(size)
    va = chart.value_axis
    va.has_major_gridlines = True
    va.major_gridlines.format.line.color.rgb = RGBColor(0xE3, 0xE3, 0xE3); va.major_gridlines.format.line.width = Pt(0.5)
    va.format.line.fill.background()
    if ymin is not None: va.minimum_scale = ymin
    if ymax is not None: va.maximum_scale = ymax
    if major: va.major_unit = major
    if fmt: va.tick_labels.number_format = fmt; va.tick_labels.number_format_is_linked = False
    va.tick_labels.font.size = Pt(size)
    ca = chart.category_axis; ca.tick_labels.font.size = Pt(size); ca.format.line.color.rgb = RGBColor(0x88, 0x88, 0x88)
    ca.has_major_gridlines = False
    borderless(chart)
    bp = ca._element.find('{http://schemas.openxmlformats.org/drawingml/2006/chart}txPr')
    if bp is not None:
        bp.find('{http://schemas.openxmlformats.org/drawingml/2006/main}bodyPr').set('rot', '0')

def borderless(chart):
    from pptx.oxml.ns import qn
    from lxml import etree
    cs = chart._chartSpace
    sp = cs.find(qn('c:spPr'))
    if sp is None:
        sp = etree.SubElement(cs, qn('c:spPr'))
        cs.remove(sp); cs.insert(len(cs) - (1 if cs.find(qn('c:txPr')) is not None else 0), sp)
    for ch in list(sp): sp.remove(ch)
    etree.SubElement(sp, qn('a:noFill')); ln = etree.SubElement(sp, qn('a:ln')); etree.SubElement(ln, qn('a:noFill'))
    # category labels horizontal
    tx = chart.category_axis.tick_labels._element if False else None

def color(chart, cols, gap=60, overlap=None):
    plot = chart.plots[0]; plot.gap_width = gap
    if overlap is not None: plot.overlap = overlap
    for ser, c in zip(plot.series, cols):
        ser.format.fill.solid(); ser.format.fill.fore_color.rgb = c; ser.format.line.fill.background()

PW, TOP, CH = 1.88, 0.42, 1.88    # panel width, chart top, chart height
xs = [0.05, 0.05 + PW + 0.08, 0.05 + 2 * (PW + 0.08), 0.05 + 3 * (PW + 0.08)]
TITLES = [('(a) Coordination dominates cost', 'planner + reviewer: 52–58% of tokens'),
          ('(b) Most tasks need no team', 'pipeline-solved tasks solved by L₀'),
          ('(c) Confidence barely tells which', 'AUROC of L₀ confidence; chance = 0.5'),
          ('(d) Uncertified rules vary', 'accuracy loss vs. pipeline (points)')]
for x, (t, sub) in zip(xs, TITLES):
    label(x, 0.02, PW, 0.2, [[(t, {'bold': True, 'size': 8.5})]])
    label(x, 0.20, PW, 0.2, [[(sub, {'italic': True, 'color': SOFT, 'size': 6.8})]])

# (a) 100% stacked bars: token share by role
cd = CategoryChartData(); cd.categories = ['DeepSeek', 'GLM']   # bar charts plot bottom-up
for i, role in enumerate(['Planner', 'Executor', 'Reviewer']):
    cd.add_series(role, [ROLES['DeepSeek'][i], ROLES['GLM'][i]])
ch = s.shapes.add_chart(XL_CHART_TYPE.BAR_STACKED_100, Inches(xs[0]), Inches(TOP), Inches(PW), Inches(CH), cd).chart
style(ch, fmt='0%'); color(ch, [PLAN_C, EXE_C, REV_C], gap=45, overlap=100)
pl = ch.plots[0]; pl.has_data_labels = True; dl = pl.data_labels
dl.number_format = '0"%"'; dl.number_format_is_linked = False; dl.font.size = Pt(7); dl.position = XL_LABEL_POSITION.CENTER
ch.value_axis.visible = False

# (b) clustered columns: share already solved by L0
cd = CategoryChartData(); cd.categories = BENCH
for fam in ('GLM', 'DeepSeek'):
    cd.add_series(fam, [D[f'{fam}|{b}']['solved'] for b in BENCH])
ch = s.shapes.add_chart(XL_CHART_TYPE.COLUMN_CLUSTERED, Inches(xs[1]), Inches(TOP), Inches(PW), Inches(CH), cd).chart
style(ch, ymin=0, ymax=100, major=25, fmt='0"%"', size=6.5); color(ch, [GLM_C, DS_C], gap=55, overlap=-5)
ch.category_axis.tick_labels.font.size = Pt(6)

# (c) clustered columns: AUROC, axis from 0.5 (chance) to 1.0 (perfect)
cd = CategoryChartData(); cd.categories = BENCH
for fam in ('GLM', 'DeepSeek'):
    cd.add_series(fam, [D[f'{fam}|{b}']['auc'] for b in BENCH])
ch = s.shapes.add_chart(XL_CHART_TYPE.COLUMN_CLUSTERED, Inches(xs[2]), Inches(TOP), Inches(PW), Inches(CH), cd).chart
style(ch, ymin=0.5, ymax=1.0, major=0.1, fmt='0.0', size=6.5); color(ch, [GLM_C, DS_C], gap=55, overlap=-5)
ch.category_axis.tick_labels.font.size = Pt(6)
ch.value_axis.crosses_at = 0.5 if hasattr(ch.value_axis, 'crosses_at') else None

# (d) fixed threshold vs CLIMB accuracy loss, 8 settings
cats = [f"{'G' if f == 'GLM' else 'D'}·{b[:2] if b != 'MuSiQue' else 'Mu'}" for f in ('GLM', 'DeepSeek') for b in BENCH]
cd = CategoryChartData(); cd.categories = cats
cd.add_series('Always L₁', [D[f'{f}|{b}']['l1_loss'] for f in ('GLM', 'DeepSeek') for b in BENCH])
cd.add_series('Fixed threshold', [D[f'{f}|{b}']['fixed_loss'] for f in ('GLM', 'DeepSeek') for b in BENCH])
cd.add_series('CLIMB (ε = 5%)', [D[f'{f}|{b}']['climb_loss'] for f in ('GLM', 'DeepSeek') for b in BENCH])
ch = s.shapes.add_chart(XL_CHART_TYPE.COLUMN_CLUSTERED, Inches(xs[3]), Inches(TOP), Inches(PW), Inches(CH), cd).chart
style(ch, ymin=-3, ymax=10, major=2, fmt='0', size=6.5); color(ch, [RGBColor(0x9E, 0x9E, 0x9E), FIX_C, CLIMB_C], gap=30, overlap=-5)
ch.category_axis.tick_label_position = XL_TICK_LABEL_POSITION.LOW
prs.save('figure1.pptx'); print('saved figure1.pptx')
